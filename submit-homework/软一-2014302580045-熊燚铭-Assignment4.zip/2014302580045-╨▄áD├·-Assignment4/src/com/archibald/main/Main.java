package com.archibald.main;

/**
 * @author Archibaldx
 * Interface of program
 */
public class Main {
	public static void main(String[] args) {
		MainFrame frm = new MainFrame();
		frm.init();
	}
}
