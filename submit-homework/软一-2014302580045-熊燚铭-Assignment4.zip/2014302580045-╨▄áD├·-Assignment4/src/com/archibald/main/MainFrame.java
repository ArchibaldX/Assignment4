package com.archibald.main;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.archibald.data.DataProcessor;
import com.archibald.data.ProfessorInfo;

/**
 * @author Archibaldx
 *	Frames
 */
public class MainFrame extends JFrame {
	private static final long serialVersionUID = 3963287935697304773L;
	
	//Components
	private JTextField tf_search = null;
	private JTextArea ta_answer = null;
	private JButton btn_search = null;
	private JScrollPane ta_scroll =null;
	
	private FlowLayout top_layout =null;
	private BorderLayout main_layout =null;
	private JPanel top_panel = null;
	
	private DataProcessor dpr;
	
	public MainFrame() {
		dpr = new DataProcessor();
		tf_search = new JTextField(20);
		ta_answer = new JTextArea();
		ta_scroll = new JScrollPane(ta_answer);
		btn_search = new JButton("����");
		top_layout = new FlowLayout();
		main_layout = new BorderLayout();
		top_panel = new JPanel();
	}
	
	
	/**
	 * Init Parameters
	 */
	public void init(){
		this.setLayout(main_layout);
		this.add(top_panel, BorderLayout.NORTH);
		this.add(ta_scroll, BorderLayout.CENTER);
		
		initTop();
		initEvents();
		addContent();
		this.setLocation(100, 100);
		this.setSize(800, 600);
		this.setVisible(true);
		
	}
	
	/**
	 * Init top Layout
	 */
	private void initTop(){
		top_panel.setLayout(top_layout);
		top_panel.add(tf_search);
		top_panel.add(btn_search);
	}
	
	/**
	 * Init Events
	 */
	private void initEvents(){
		BtnListener btn_lis = new BtnListener();
		btn_search.addActionListener(btn_lis);
	}
	
	
	/**
	 * Add Content to JTextArea
	 */
	private void addContent(){
		ta_answer.setText("");
		ArrayList<ProfessorInfo> list = dpr.getList();
		for(ProfessorInfo e:list){
			ta_answer.append("TF:"+e.getWeight()+"      "+e.toString()+"\n\r");
		}
	}
	
	
	/**
	 * @author Archibaldx
	 * Button Listener
	 */
	private class BtnListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			Object obj=e.getSource();
			if(obj == btn_search){
				dpr.search(tf_search.getText());
				addContent();
			}
			
		}
		
	}
	
	
	
}
