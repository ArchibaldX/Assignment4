package com.archibald.data;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


/**
 * @author Archibaldx
 *	
 */
public class DataProcessor {
	public static DBHelper db = new DBHelper("localhost", 3306, "root", "123456", "_professor_info");

	/**
	 * Used to Save Professor's Information
	 */
	private ArrayList<ProfessorInfo> list;


	public DataProcessor() {
		list = new ArrayList<ProfessorInfo>();
		init();
	}

	/**
	 * init Databases and infomation
	 */
	private void init(){
		db.Connect();
		ProfessorInfo pif = null;
		try {
			//Print the result
			ResultSet rs = db.execQuerySQL("select * from _professor_info;");
			while(rs.next()){
				pif = new ProfessorInfo(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				list.add(pif);
			}
		} catch (Exception e) {
			System.out.print("");
		}
		db.closeConn();
	}

	/**
	 * sort data by Weight
	 */
	public void sortData(){
		Sort sort = new Sort();
		Collections.sort(list,sort);
	}

	/**
	 * @param content
	 * search the professorinfos judged by content
	 */
	public void search(String content){
		resetWeight();
		String [] sear = content.replaceAll(",", " ").split(" ");
		for(String s:sear){
			if(s.equals(""))continue;
			searchElem(s.trim());
		}

	}

	/**
	 * @param regex
	 * Search infos judge by a single word
	 * 
	 */
	private void searchElem(String regex){
		for(ProfessorInfo e:list){
			int counter = 0;
			for (int i = 0; i <= e.toString().length() - regex.length(); i++) {
				if (e.toString().substring(i, i + regex.length()).equalsIgnoreCase(regex)) {
					counter++;
				}
			}
			e.setWeight(counter);
		}
		sortData();
	}

	/**
	 * resetWeight
	 */
	private void resetWeight(){
		for(ProfessorInfo e:list){
			e.setWeight();
		}
	}

	/**
	 * @return
	 */
	public ArrayList<ProfessorInfo> getList(){
		return list;
	}

	/**
	 * @author Archibaldx
	 *	sortData
	 */
	class Sort implements Comparator<ProfessorInfo>{
		@Override
		public int compare(ProfessorInfo data1, ProfessorInfo data2) {
			return data1.getWeight() > data2.getWeight() ? -1 : 1;
		}

	}
}