package com.archibald.data;

public class ProfessorInfo {
	//The basic Infos
	private String name;
	private String phone;
	private String email;
	private String educationBackground;
	private String researchInterests;
	private double weight;
	private int totalNum;
	
	public ProfessorInfo(String name,String background,String interests,String Email,String Phone) {
		this.name = name;
		this.phone = Phone;
		this.email = Email;
		this.educationBackground = background;
		this.researchInterests = interests.replaceAll("\n", " ");
		weight = 0.0;
		setTotalNum();
	}
	
	private void setTotalNum(){
		this.totalNum = getNum(name.split(" "))+getNum(educationBackground.split(" "))+getNum(researchInterests.split(" "));
	}
	
	public void setWeight(int num){
		weight += (double)num/(double)totalNum;
	}
	
	public void setWeight(){
		weight =0;
	}
	
	
	public double getWeight(){
		return weight;
	}
	
	
	private int getNum(String[] str){
		int i=0;
		for(String s:str){
			s.trim();
			i++;
		}
		return i;
	}
	
	
	public String getName(){
		return name;
	}
	
	public String getPhone(){
		return phone;
	}
	
	public String getEmail(){
		return email;
	}
	
	public String getEducationBackGround(){
		return educationBackground;
	}
	
	public String getResearchInterest(){
		return researchInterests;
	}
	
	public int getTotalNum(){
		return totalNum;
	}
	
	@Override
	public String toString() {
		return getName()+" "+getPhone()+" "+getEmail()+" "+getEducationBackGround()+" "+getResearchInterest();
	}
}




